import oop_and_patterns.week05.final_project.Service as Service
import oop_and_patterns.week05.final_project.Objects as Objects


class GameEngine:
    objects = []
    map = None
    hero = None
    hero_alive = False
    level = -1
    working = True
    subscribers = set()
    score = 0.
    game_process = True
    show_help = False

    def subscribe(self, obj):
        self.subscribers.add(obj)

    def unsubscribe(self, obj):
        if obj in self.subscribers:
            self.subscribers.remove(obj)

    def notify(self, message):
        for i in self.subscribers:
            i.update(message)

    # HERO
    def add_hero(self, hero):
        """
        :param hero:
        :type hero: Objects.Hero
        :return:
        :rtype: None
        """
        self.hero = hero
        self.hero_alive = True

    def interact(self):
        """
        Hero tries to interact with all objects on the map. If hero's positions
        and object's positions are the same, they interact with each other.
        :return:
        :rtype: None
        """
        for obj in self.objects:
            if list(obj.position) == self.hero.position:
                obj.interact(self, self.hero)

    def kill_hero(self):
        self.hero_alive = False

    # MOVEMENT
    def move_up(self):
        self.score -= 0.02
        if self.map[self.hero.position[1] - 1][
            self.hero.position[0]] == Service.wall:
            return
        self.hero.position[1] -= 1
        self.interact()

    def move_down(self):
        self.score -= 0.02
        if self.map[self.hero.position[1] + 1][
            self.hero.position[0]] == Service.wall:
            return
        self.hero.position[1] += 1
        self.interact()

    def move_left(self):
        self.score -= 0.02
        if self.map[self.hero.position[1]][
            self.hero.position[0] - 1] == Service.wall:
            return
        self.hero.position[0] -= 1
        self.interact()

    def move_right(self):
        self.score -= 0.02
        if self.map[self.hero.position[1]][
            self.hero.position[0] + 1] == Service.wall:
            return
        self.hero.position[0] += 1
        self.interact()

    # MAP
    def load_map(self, game_map):
        self.map = game_map

    # OBJECTS
    def add_object(self, obj):
        self.objects.append(obj)

    def add_objects(self, objects):
        self.objects.extend(objects)

    def delete_object(self, obj):
        self.objects.remove(obj)
